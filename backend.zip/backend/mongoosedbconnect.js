const mongoose=require('mongoose')
const uri = "mongodb+srv://admin:yBi5VSkqtwGKGs4L@cluster0.bavlq.mongodb.net/capstone?retryWrites=true&w=majority"

mongoose.connect(uri,{ useUnifiedTopology: true, useNewUrlParser: true },(err)=>{
console.log('connected')
})
require('./model/usermodel')
require('./model/itemmodel')