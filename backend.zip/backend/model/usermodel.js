const mongoose = require ('mongoose')
var userschema=new mongoose.Schema
({
    username:{
        type:String,
        required: true,
        unique: true
    },
    password:{
        type:String,
        required: true,
    },
    usertype:{
        type:String,
        required: true,
        enum: ['admin', 'user'],
    }
})
module.exports=mongoose.model('user',userschema, 'user')