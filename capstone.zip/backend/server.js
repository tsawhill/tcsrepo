var express = require('express')
var mongoose = require('mongoose')
var cors = require('cors')
require ('./mongoosedbconnect')
var User = require('./model/usermodel')
var Item = require('./model/itemmodel')

var app = express()

app.use(express.json())
app.use(cors())

/*app.get('/api/test', (req, res)=>{
    res.status(200).json('hello!')
})
*/

app.get('/api/usertype/:username/:password', (req,res)=>{
    User.find({
        username: {
            "$in": [req.params.username]
        },
        password:{
            "$in": [req.params.password]
        }
    }).then((user)=>{
        if(user[0])
            res.status(200).json(user[0].usertype)
        else
            res.status(200).json("Error")
    })
})

app.post('/api/adduser', (req, res)=>{
    newUser = req.body
    User.find({
        username: {
            "$in": [newUser.username]
        }
    }).then((user)=>{
        if(user[0])
            res.status(200).json("Error, username taken")
        else{
            var user = new User({
                username: newUser.username,
                password: newUser.password,
                usertype: newUser.usertype,
            })
            user.save(function(err){
                if(err)
                    res.status(200).json(err)
                else
                    res.status(200).json('Success')
            })
        }
    })
})

app.post('/api/deleteuser/:username', (req,res)=>{
    User.find({
        username: {
            "$in": [req.params.username]
        }
    }).then((user)=>{
        if(!user[0])
            res.status(400).json("User does not exist!")
        else{
            User.findOneAndRemove({
                username: req.params.username
            }).then((removed, err) =>{
                if(err)
                    res.status(400).json(err)
                else
                    res.status(200).json(`User ${removed.username} removed.`)
            })
        }
    })
})

app.post('/api/deleteitem/:name', (req,res)=>{
    Item.find({
        name: {
            "$in": [req.params.name]
        }
    }).then((item)=>{
        if(!item[0])
            res.status(400).json("Item does not exist!")
        else{
            Item.findOneAndRemove({
                name: req.params.name
            }).then((removed, err) =>{
                if(err)
                    res.status(400).json(err)
                else
                    res.status(200).json(`Item ${removed.name} removed.`)
            })
        }
    })
})

app.post('/api/additem', (req, res)=>{
    newItem = req.body
    User.find({
        username: {
            "$in": [newItem.name]
        }
    }).then((result)=>{
        if(result[0])
            res.status(400).json("Error, item exists")
        else{
            var item = new Item({
                name: newItem.name,
                price: newItem.price,
                description: newItem.description
            })
            item.save(function(err){
                if(err)
                    res.status(400).json(err)
                else
                    res.status(200).json('Success')
            })
        }
    })
})
app.get('/api/getitems', (req,res)=>{
    Item.find().then(result=>{
        res.status(200).json(result)
    })
})
app.get('/api/getusers', (req,res)=>{
    User.find().then(result=>{
        res.status(200).json(result)
    })
})
app.put('/api/updateuser', async (req,res)=>{
    newUser = req.body

    user = await User.findOneAndUpdate({"username": newUser.username}, newUser)
    if(user)
        res.status(200).json(user)
    else
        res.status(400).json(`Error: User ${newUser.username} does not exist!`)
})
app.put('/api/updateitem', async (req,res)=>{
    newItem = req.body

    item = await Item.findOneAndUpdate({"name": newItem.name}, newItem)
    if(item)
        res.status(200).json(item)
    else
        res.status(400).json(`Error: Item ${newItem.name} does not exist!`)
})

app.listen(3000,()=>{
    console.log('Server running at port 3000')
})


