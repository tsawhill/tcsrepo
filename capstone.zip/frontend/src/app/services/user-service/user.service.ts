import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  usertype = ''

  get type(): String{
    return this.usertype
  }

  constructor(private http: HttpClient) { }

  login(user, pass): Promise<boolean>{
    return new Promise<boolean>((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)
      this.http.get<any>(`http://localhost:3000/api/usertype/${user}/${pass}`).subscribe(data =>{
        if(data !== 'Error'){
          this.usertype = data
          res(true)
        }
        else
          res(false)
      })
      
    })
  }

  getUsers(): Promise<any>{
    return new Promise((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)
      this.http.get<any>(`http://localhost:3000/api/getusers`).subscribe(data =>{
        if(data !== 'Error'){
          var test = data
          res(test)
        }
        else
          res(false)
      })
    })
  }
  deleteUser(name): Promise<string>{
    console.log(name)
    return new Promise<string>((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)
      this.http.post<any>(`http://localhost:3000/api/deleteuser/${name.username}`, {}).subscribe(data =>{
        res(data)
      })
      
    })
  }
  createUser(user, pass, type): Promise<string>{
    return new Promise<string>((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)

      this.http.post<any>(`http://localhost:3000/api/adduser`, {username: user, password: pass,usertype: type}).subscribe(data =>{
        res(data)
      })
      
    })
  }

  updateUser(user, pass, type): Promise<string>{
    return new Promise<string>((res, rej)=>{
      setTimeout(()=> rej("Timed out."), 5000)

      this.http.put<any>(`http://localhost:3000/api/updateuser`, {username: user, password: pass,usertype: type}).subscribe(data =>{
        res(data.username)
      })
      
    })
  }
}
