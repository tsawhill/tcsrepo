import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemService } from '../services/item-service/item.service';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-delete-item',
  templateUrl: './delete-item.component.html',
  styleUrls: ['./delete-item.component.css']
})
export class DeleteItemComponent implements OnInit {
  myForm: FormGroup
  item: FormControl
  userType = ''
  message = ''
  items = []
  constructor(private is: ItemService, private us: UserService, private r: Router) { }

  ngOnInit(): void {
    this.createForm()

    if(this.us.usertype)
      this.userType = this.us.usertype
    else
      this.r.navigate(['/login'])


    this.is.getItems().then(res=>{
      this.items = res      
    })     
  }

  createForm(){
    this.myForm = new FormGroup({
      item: new FormControl(),
    })
  }

  public trackItem (index, item) {
    return item.trackId;
  }

  deleteItem(){
    console.log(this.myForm.value.item)
    this.is.deleteItem(this.myForm.value.item.name).then(result=>{
      this.message = result
    })
    this.is.getItems().then(res=>{
      this.items = res      
    })
  }
}
