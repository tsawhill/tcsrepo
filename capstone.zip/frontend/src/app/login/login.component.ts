import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { rejects } from 'assert';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  myForm: FormGroup
  uname: FormControl
  pass: FormControl
  failedLogin: boolean

  constructor(private r: Router, private us: UserService) { }

  ngOnInit(): void {
    this.createForm()
    this.failedLogin = false
  }
  createForm(){
    this.myForm = new FormGroup({
      uname: new FormControl(),
      pass: new FormControl()
    })
  }
  login(){
    this.us.login(this.myForm.value.uname, this.myForm.value.pass).then(success =>{
      if(success){
        console.log("Success")
        this.r.navigate(['/landingpage'])
      }
      else{
        this.failedLogin = true
        this.myForm.reset()
      }
      
  })

    
  }

}
