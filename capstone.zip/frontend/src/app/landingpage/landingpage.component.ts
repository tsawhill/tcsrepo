import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../services/cart-service/cart.service';
import { ItemService } from '../services/item-service/item.service';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-landingpage',
  templateUrl: './landingpage.component.html',
  styleUrls: ['./landingpage.component.css']
})
export class LandingpageComponent implements OnInit {
  userType: String
  items= []
  itemCount = 0
  constructor(private us: UserService, private r: Router, private cs: CartService, private is: ItemService) { }

  ngOnInit(): void {
    if(this.us.usertype)
      this.userType = this.us.usertype
    else
      this.r.navigate(['/login'])

    this.is.getItems().then(res=>{
      this.items = res
    })    
  }

  addItem(newItem){
    this.cs.addItem(newItem)
    this.itemCount++
  }

}
