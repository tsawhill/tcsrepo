import { useAnimation } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import {faShoppingCart} from '@fortawesome/free-solid-svg-icons';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  userType
  faShoppingCart = faShoppingCart
  constructor(private us: UserService) { }

  ngOnInit(): void {
    this.userType = this.us.usertype
    console.log(this.userType)
  }

}
