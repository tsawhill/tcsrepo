import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemService } from '../services/item-service/item.service';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  myForm: FormGroup
  user: FormControl
  pass: FormControl
  type: FormControl
  message = ''
  users = []

  userType = ''

  createForm(){
    this.myForm = new FormGroup({
      user: new FormControl(),
      pass: new FormControl(),
      type: new FormControl()
    })
  }

  constructor(private us: UserService, private is: ItemService, private r: Router) { }

  ngOnInit(): void {
    this.createForm()

    /*if(this.us.usertype)
      this.userType = this.us.usertype
    else
      this.r.navigate(['/login'])*/

      this.us.getUsers().then(res=>{
        this.users = res      
      })  
      
   
  }

  onSubmit(){
    this.us.updateUser(this.myForm.value.user.username,this.myForm.value.pass,this.myForm.value.tyoe).then(res =>{
      this.message = `User ${res} successfully updated.`
      this.myForm.reset()
    })
    
  }
}
