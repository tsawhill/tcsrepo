import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemService } from '../services/item-service/item.service';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  myForm: FormGroup
  uname: FormControl
  pass: FormControl
  type: FormControl

  message = ''

  userType = ''

  createForm(){
    this.myForm = new FormGroup({
      uname: new FormControl(),
      pass: new FormControl(),
      type: new FormControl()
    })
  }

  constructor(private us: UserService, private is: ItemService, private r: Router) { }

  ngOnInit(): void {
    this.createForm()

   /* if(this.us.usertype)
      this.userType = this.us.usertype
    else
      this.r.navigate(['/login'])
   */
  }

  onSubmit(){
    this.us.createUser(this.myForm.value.uname,this.myForm.value.pass,this.myForm.value.type).then(res =>{
      this.message = res
    })
  }
}
