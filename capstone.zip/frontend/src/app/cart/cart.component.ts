import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../services/cart-service/cart.service';
import { UserService } from '../services/user-service/user.service';
import {MatIconModule} from '@angular/material/icon';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  userType = ''
  myCart = []
  totalCost = 0

  constructor(private us: UserService, private r: Router, private cs: CartService) { }

  ngOnInit(): void {
    if(this.us.usertype)
      this.userType = this.us.usertype
    else
      this.r.navigate(['/login'])
    this.myCart = this.cs.myCart
    this.calculateTotal()
  }

  calculateTotal(){
    for(let x of this.myCart){
      this.totalCost += (x.item.price * x.qty)
    }
  }

}
