import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ItemService } from '../services/item-service/item.service';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.css']
})
export class AddItemComponent implements OnInit {
  myForm: FormGroup
  name: FormControl
  price: FormControl
  desc: FormControl
  message = ''

  userType = ''

  createForm(){
    this.myForm = new FormGroup({
      name: new FormControl(),
      price: new FormControl(),
      desc: new FormControl()
    })
  }

  constructor(private us: UserService, private is: ItemService, private r: Router) { }

  ngOnInit(): void {
    this.createForm()

    if(this.us.usertype)
      this.userType = this.us.usertype
    else
      this.r.navigate(['/login'])
   
  }

  onSubmit(){
    this.is.createItem(this.myForm.value.name,this.myForm.value.price,this.myForm.value.desc).then(res =>{
      this.message = res
    })
  }
}
