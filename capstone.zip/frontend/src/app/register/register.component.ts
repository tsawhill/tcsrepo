import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user-service/user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  myForm: FormGroup
  uname: FormControl
  pass: FormControl
  message = ''

  constructor(private us: UserService, private r: Router) { }

  ngOnInit(): void {
    this.createForm()
  }
  createForm(){
    this.myForm = new FormGroup({
      uname: new FormControl(),
      pass: new FormControl()
    })
  }

  register(){
    console.log(this.myForm.value.uname, this.myForm.value.pass)
    this.us.createUser(this.myForm.value.uname, this.myForm.value.pass, 'user').then(res =>{
      this.message = res
   })
  }


}


