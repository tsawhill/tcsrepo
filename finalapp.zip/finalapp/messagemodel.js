const mongoose = require ('mongoose')
var messageschema=new mongoose.Schema
({
    name:{
        type:String,
    },
    text:{
        type:String,
    },
    timestamp:{
        type: Date,
    },
    room:{
        type:String
    }
})

function collection(col){
    return mongoose.model('message', messageschema, col)
}

module.exports=mongoose.model('message',messageschema)