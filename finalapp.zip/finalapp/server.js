var PORT = process.env.PORT || 8000;
var moment = require('moment');
var express = require('express');
var mongoose = require('mongoose')
require('./mongoosedbconnect')
const Message = require('./messagemodel')

const { SSL_OP_EPHEMERAL_RSA, RSA_PKCS1_PADDING } = require('constants');
const { CLIENT_RENEG_LIMIT } = require('tls');
var app = express();
var http = require('http').Server(app);
var io = require('socket.io')(http);


app.use(express.static(__dirname + '/public'));

var clientInfo = {};
// Sends current users to provided socket
function sendCurrentUsers (socket) {
	var info = clientInfo[socket.id];
	var users = [];

	if (typeof info === 'undefined') {
		return;
	}

	Object.keys(clientInfo).forEach(function (socketId) {
		var userInfo = clientInfo[socketId];

		if (info.room === userInfo.room) {
			users.push(userInfo.name);
		}
	});

	socket.emit('message', {
		name: 'System',
		text: 'Current users: ' + users.join(', '),
		timestamp: moment().valueOf()
	});
}
io.on('connection', function (socket) {
	console.log('User connected via socket.io!');

	socket.on('disconnect', function () {
		var userData = clientInfo[socket.id];

		
		if (typeof userData !== 'undefined') {
			socket.leave(userData.room);

			//Create message and store message to database
			var msg = new Message( {
				name: 'System',
				text: userData.name + ' has left!',
				timestamp: moment().valueOf(),
				room: userData.room
			})
			msg.save()

			io.to(userData.room).emit('message', msg);
			delete clientInfo[socket.id];
		}
	});

	socket.on('joinRoom', function (req) {
		//Create message and store message to database
		var msg = new Message({
			name: 'System',
			text: req.name + ' has joined!',
			timestamp: moment().valueOf(),
			room: req.room
		})
		msg.save()
		
		clientInfo[socket.id] = req;
		socket.join(req.room);
		socket.broadcast.to(req.room).emit('message', msg);		
	});

	socket.on('message', function (message) {
		console.log('Message received: ' + message.text);


		if (message.text === '@currentUsers') {
			sendCurrentUsers(socket);
		} else {
			message.timestamp = moment().valueOf();
			io.to(clientInfo[socket.id].room).emit('message', message);	
		}

		//Create message and store message to database
		var msg = new Message({
			name: message.name,
			text: message.text,
			timestamp: message.timestamp,
			room: clientInfo[socket.id].room
		})
		msg.save()
		
	});

	//Pull messages from database
	var messages = []
	Message.find().sort({ $natural: -1 }).then((res)=>{
		//Filter messages - 5 most recent from current room
		result = res
		i = 0
		while(messages.length < 5 && i < result.length){
			if(result[i].room === clientInfo[socket.id].room)
				messages.push(result[i])
			i++
		}
		//Reverse for sequential order
		messages.reverse()
		for(let x of messages){
			socket.emit('message', x)
		}

		socket.emit('message', {
			name: 'System',
			text: `You joined room: ${clientInfo[socket.id].room}! Welcome to the chat application!`,
			timestamp: moment().valueOf()
		})
	})

	

	
	
});

http.listen(PORT, function () {
	console.log('Server started!');
});