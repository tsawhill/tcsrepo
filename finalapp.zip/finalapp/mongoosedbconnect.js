const mongoose=require('mongoose')
const uri = "mongodb+srv://admin:yBi5VSkqtwGKGs4L@cluster0.bavlq.mongodb.net/tcsdb?retryWrites=true&w=majority"

mongoose.connect(uri,{ useUnifiedTopology: true },(err)=>{
console.log('connected')
})
require('./messagemodel')