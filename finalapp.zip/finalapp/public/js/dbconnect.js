const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://admin:yBi5VSkqtwGKGs4L@cluster0.bavlq.mongodb.net/tcsdb?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true });
client.connect(err => {
  const collection = client.db("tcsdb").collection("userapp");
  // perform actions on the collection object
    console.log('Connected')
});